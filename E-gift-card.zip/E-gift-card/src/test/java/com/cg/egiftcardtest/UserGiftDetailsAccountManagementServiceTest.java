package com.cg.egiftcardtest;

public class UserGiftDetailsAccountManagementServiceTest {

}
