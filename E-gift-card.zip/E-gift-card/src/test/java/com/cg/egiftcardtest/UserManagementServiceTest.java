package com.cg.egiftcardtest;

	import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.UnsupportedEncodingException;

import javax.mail.MessagingException;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;

import com.cg.egiftcard.EGiftCardApplication;
import com.cg.egiftcard.entity.User;
import com.cg.egiftcard.exception.InvalidInputException;
import com.cg.egiftcard.exception.UserCustomExceptions;
import com.cg.egiftcard.repository.UserRepository;
import com.cg.egiftcard.service.UserManagementService;

	@SpringBootTest
	@ContextConfiguration(classes = EGiftCardApplication.class)
	@TestMethodOrder(MethodOrderer.OrderAnnotation.class)

	public class UserManagementServiceTest {
	

		@Autowired
		private UserManagementService managementService;

		@Autowired
		private UserRepository repository;

		@Test
		void testGetAllUsers() {
			User user = new User(23L, "Akash", "Kumar", "Akashkumar@gmail.com", "9900123123", "Akash@123", "xyz");
			repository.save(user);
			assertNotNull(managementService.getAllUsers());
			repository.delete(user);
		}

		@Test
		void testGetUserByEmailPass() throws InvalidInputException, UserCustomExceptions {
			User user = new User(24L, "Akash", "Kumar", "Durgesh1@gmail.com", "9900123123", "Akash@123", "xyz");
			repository.save(user);
			assertEquals(user, managementService.getUserByEmail(user.getEmail()));
			repository.delete(user);

		}

		@Test
		void testupdateUserPassword() throws UnsupportedEncodingException, UserCustomExceptions, InvalidInputException, MessagingException {
			User user = new User(24L, "Akash", "Kumar", "Durgesh1@gmail.com", "9900123123", "Akash@123", "xyz");
			repository.save(user);
			//updated object
			User updatedUser = new User(24L, "Akash", "Kumar", "Durgesh1@gmail.com", "9900123123", "12345678", "xyz");
			assertEquals(updatedUser, managementService.updateUserPassword("Durgesh1@gmail.com","Akash@123" , "12345678"));
			repository.delete(updatedUser);
			
		}

		@Test
		void testSearchUsers() {
			User user = new User(24L, "Akash", "Kumar", "Durgesh1@gmail.com", "9900123123", "Akash@123", "xyz");
			repository.save(user);
			assertNotNull(managementService.searchUsers("Akash"));
			repository.delete(user);
			
		}

	}

