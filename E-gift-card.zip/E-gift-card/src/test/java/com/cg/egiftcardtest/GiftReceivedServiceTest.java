package com.cg.egiftcardtest;

public class GiftReceivedServiceTest {

}
