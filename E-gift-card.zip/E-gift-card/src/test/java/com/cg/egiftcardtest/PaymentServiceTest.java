//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.mockito.Mockito.when;
//
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import static org.junit.
//import org.mockito.Mockito;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import com.cg.egiftcard.entity.PaymentDetails;
//import com.cg.egiftcard.repository.PaymentRepository;
//ter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.mockito.Mockito.when;
//
//import java.time.LocalDate;
//import java.time.LocalDateTime;
//import java.util.ArrayList;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.junit.jupiter.MockitoExtension;
//
//import com.cg.egiftcard.repository.PaymentRepository;
//import com.cg.egiftcard.service.PaymentServiceImpl;
//
////import static org.junit.Assert.assertEquals;
//// 
////import static org.junit.Assert.assertNotNull;
////import static org.junit.Assert.fail;
////import static org.mockito.Mockito.when;
//// 
////import java.time.LocalDate;
////import java.time.LocalDateTime;
////import java.util.ArrayList;
////import java.util.List;
////import java.util.Optional;
//// 
////import org.assertj.core.util.Arrays;
////import org.junit.Assert;
////import org.junit.jupiter.api.Order;
////import org.junit.jupiter.api.Test;
////import org.junit.jupiter.api.extension.ExtendWith;
////import org.junit.runner.RunWith;
////import org.mockito.InjectMocks;
////import org.mockito.Mock;
////import org.mockito.Mockito;
////import org.mockito.junit.MockitoJUnitRunner;
////import org.mockito.junit.jupiter.MockitoExtension;
////import org.springframework.beans.factory.annotation.Autowired;
//// 
////import com.cg.nutritions.entity.Gender;
////import com.cg.nutritions.entity.Payment;
////import com.cg.nutritions.entity.Role;
////import com.cg.nutritions.entity.UserTable;
////import com.cg.nutritions.exceptions.ResourceNotFoundException;
////import com.cg.nutritions.repository.PaymentRepository;
//// 
////@SpringBootTest
////@RunWith(MockitoJUnitRunner.class)
//@ExtendWith(MockitoExtension.class)
//class PaymentServiceTest {
//     private static final Class<NullPointerException> expeted = null;
//     @InjectMocks
////@Autowired
//    private PaymentServiceImpl paymentService;
//
//     @Mock
////@Autowired
//    private PaymentRepository paymentRepository; 
//
//     @Test
//        public void testCreatePayment() throws Exception {
//            PaymentDetails p = new PaymentDetails();
//            p.setPaymentId((int) 1);
//            p.setPaymentDate("2023-03-11");
//            p.setPaymentAmount(3000.00);
//            p.setNameOntheCard("Suni");
//            p.setCardNumber("150004567823145");
//            p.setCardExpiry(05-25);
//            
//            UserTable u = new UserTable();
//            u.setUserId(23L);
//            u.setUserName("Akash");
//            u.setAllergicTool("xyz");
//            u.setContactNo("9900123100");
//            u.setDob(LocalDate.of(1999, 11, 21));
//            u.setEmail("xyz12@gmail.com");
//            u.setGender(Gender.MALE);
//            u.setHeight(5.8);
//            u.setMedicalCondition("Normal");
//            u.setName("AkashKumar");
//            u.setPassword("Abc1234567");
//            u.setRole(Role.ADMIN);
//            u.setSleepTime(LocalDateTime.parse("2023-12-31T15:53:16"));
//            u.setWakeupTime(LocalDateTime.parse("2023-12-31T06:53:16"));
//            u.setWeight(73.5);
//            u.setWorkoutTime(2);
// 
//            Mockito.when(paymentRepository.save(p)).thenReturn(p);
//            paymentService.addPayment(p);
//            assertNotNull(p.getCreatedAt());
//            assertNotNull(p.getUpdatedAt());
//          //  assertEquals(1, p.getPymentId());
//            assertEquals(20.0, p.getDiscount(), 0);
//
//        }
// 
////    @Test
////    
////    public void testUpdatePayment() throws ResourceNotFoundException  {
////        Payment payment = new Payment();
////        payment.setCreatedAt(LocalDate.parse("2023-03-11"));
////        payment.setUpdatedAt(LocalDate.parse("2023-03-12"));
////        payment.setDiscount(10.0);
////        payment.setPlanId(1L);
////        payment.setPymentId(1L);
////        payment.setUser_id(null);
////
////        UserTable u = new UserTable();
////        u.setUserId(23L);
////        u.setUserName("");
////        u.setAllergicTool("");
////        u.setContactNo("");
////        u.setDob(LocalDate.of(1999, 11, 21));
////        u.setEmail("");
////        u.setGender(Gender.MALE);
////        u.setHeight(5.8);
////        u.setMedicalCondition("");
////        u.setName("");
////        u.setPassword("");
////        u.setRole(Role.ADMIN);
////        u.setSleepTime(LocalDateTime.parse("2023-12-31T15:53:16"));
////        u.setWakeupTime(LocalDateTime.parse("2023-12-30T15:53:16"));
////        u.setWeight(73.5);
////        u.setWorkoutTime(2);
////       // assertNotNull(paymentRepository);
////
////        
////       // Payment updatedPayment = paymentService.updatePayment(payment,1l);
////      // Assert.assertEquals(payment, updatedPayment);
////        paymentService.getClass();
////    }
//
//
////    @Test
////    public void testShowPayments()
////    {
////        Payment d= new Payment();
////        paymentRepository.save(d);
////        assertNotNull(paymentService.showPayments());
////        
////    }
//
////    
////    @Test
////    @Order(5)
////    void testShowPayment() throws ResourceNotFoundException  {
////    paymentRepository.findAll();
////    
////     }
////    
////    
////    @Test
////    public void updatePaymentTest_Success() {
////      // arrange
////      Payment payment = new Payment();
////      payment.setPaymentId(1L);
////      payment.setPlanId(2L);
////      payment.setDiscount(0.1);
////      payment.setUserId(3L);
////
////      when(paymentRepository.findById(1L)).thenReturn(Optional.of(payment));
////      when(paymentRepository.save(payment)).thenReturn(payment);
////
////      // act
////      Payment updatedPayment = paymentService.updatePayment(1L, payment);
////
////      // assert
////      assertEquals(payment, updatedPayment);
////    }
////
//    @Test
//    public void updatePaymentTest() {
//      // arrange
//      Payment payment = new Payment();
//      payment.setPymentId(1L);
//      payment.setPlanId(2L);
//      payment.setDiscount(0.1);
//      payment.setUser_id(null);
// 
//      when(paymentRepository.findById(1L)).thenReturn(Optional.of(payment));
// 
//      // act
//      try {
//        Payment updatedPayment = paymentService.updatePayment(payment, 1L);
//
//      } catch (ResourceNotFoundException ex) {
//        // assert
//        assertNotNull(ex.getMessage());
//      }
//    }
// 
//    @Test
//    public void showPayment()
//    {
//         Payment payment = new Payment();
//        List<Payment> list=new ArrayList<>();
//        list.add(payment);
//         when(paymentRepository.findAll()).thenReturn(list);
//        List<Payment> expected= paymentService.showPayments();
//        assertEquals(1, expected.size());
//
//    }
//
//    @Test
//    public void DiscountTest() {
//      // arrange
//      Payment payment = new Payment();
//      payment.setPymentId(1L);
//      payment.setPlanId(2L);
//      payment.setDiscount(0.1);
//      payment.setUser_id(null);
// 
//      when(paymentRepository.findById(1L)).thenReturn(Optional.of(payment));
// 
//      // act
//      try {
//        Payment dis = paymentService.addOffer((double) 1L,payment);
//
//      } catch (ResourceNotFoundException ex) {
//        // assert
//        assertNotNull(ex.getMessage());
//      }
//    }
//
//
//    @Test
//    public void findPaymentTest() {
//      // arrange
//      Payment payment = new Payment();
//      payment.setPymentId(1L);
//      payment.setPlanId(2L);
//      payment.setDiscount(0.1);
//      payment.setUser_id(null);
// 
//      when(paymentRepository.findById(1L)).thenReturn(Optional.of(payment));
// 
//      // act
//      try {
//        Payment f = paymentService.findPaymentById((long)1L);
//
//      } catch (ResourceNotFoundException ex) {
//        // assert
//        assertNotNull(ex.getMessage());
//      }
//    }
//
//    }
//
