package com.cg.egiftcard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EGiftCardApplicationTests {

	@Test
	void contextLoads() {
	}

}
