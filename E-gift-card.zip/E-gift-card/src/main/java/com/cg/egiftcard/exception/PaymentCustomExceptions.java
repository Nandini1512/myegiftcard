package com.cg.egiftcard.exception;

public class PaymentCustomExceptions extends Exception{
	
	public PaymentCustomExceptions(String msg){
		super(msg);
	}
}
