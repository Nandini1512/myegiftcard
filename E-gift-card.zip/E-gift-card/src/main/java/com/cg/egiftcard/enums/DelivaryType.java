package com.cg.egiftcard.enums;

public enum DelivaryType {
	ONLINE,
	OFFLINE
}