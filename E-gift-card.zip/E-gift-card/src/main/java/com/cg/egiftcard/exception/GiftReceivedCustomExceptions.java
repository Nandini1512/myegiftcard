package com.cg.egiftcard.exception;

public class GiftReceivedCustomExceptions extends Exception{
	
	public GiftReceivedCustomExceptions(String msg){
		super(msg);
	}
}
